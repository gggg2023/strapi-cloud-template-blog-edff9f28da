export const MARKETPLACE_API_URL = 'https://market-api.strapi.io';
