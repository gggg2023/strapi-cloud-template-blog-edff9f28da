export const cellWidth = `${120 / 16}rem`;
export const firstRowWidth = `${200 / 16}rem`;
export const rowHeight = `${53 / 16}rem`;
