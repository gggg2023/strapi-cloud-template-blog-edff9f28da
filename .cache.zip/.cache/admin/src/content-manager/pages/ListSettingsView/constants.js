export const EXCLUDED_SORT_ATTRIBUTE_TYPES = [
  'media',
  'richtext',
  'dynamiczone',
  'relation',
  'component',
  'json',
];
