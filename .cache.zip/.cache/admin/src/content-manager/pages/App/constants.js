export const GET_INIT_DATA = 'ContentManager/App/GET_INIT_DATA';
export const RESET_INIT_DATA = 'ContentManager/App/RESET_INIT_DATA';
export const SET_INIT_DATA = 'ContentManager/App/SET_INIT_DATA';
