import { createContext } from 'react';

const WysiwygContext = createContext();

export default WysiwygContext;
