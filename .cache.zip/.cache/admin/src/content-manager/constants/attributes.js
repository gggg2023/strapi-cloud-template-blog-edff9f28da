const CREATOR_FIELDS = ['createdBy', 'updatedBy'];

export { CREATOR_FIELDS };
