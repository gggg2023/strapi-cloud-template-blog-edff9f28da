export const useAdminRolePermissions = jest.fn().mockReturnValue({
  permissions: [],
  isLoading: false,
  isError: false,
});
