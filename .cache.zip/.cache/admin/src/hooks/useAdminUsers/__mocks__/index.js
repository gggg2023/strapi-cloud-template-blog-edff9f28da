export const useAdminUsers = jest.fn().mockReturnValue({
  users: [],
  isLoading: false,
  isError: false,
});
